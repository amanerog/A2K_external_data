"""Security-tier derivation. Source: A2K-KBCard-Schema Appendix A.3 (A2K-VAL-001).

The tier is **computed** from the card, never declared: classification level 0-1 is S0;
level 2 or ``"unknown"`` is S1; level 3-4 is S2; and ``ethicalWallSensitive`` forces S2
regardless of classification. It reads the flattened ``access`` object (``access.classificationLevel``
/ ``access.ethicalWallSensitive``), not a nested ``enterprise.access``.
"""

from __future__ import annotations

from a2k_kbcard.models.card import KBCard
from a2k_kbcard.models.registries import ClassificationLevel, SecurityTier


def security_tier_for(classification_level: ClassificationLevel, ethical_wall_sensitive: bool) -> SecurityTier:
    """Derive the security tier from a classification level and the ethical-wall flag."""
    if ethical_wall_sensitive:
        return SecurityTier.S2
    if classification_level == "unknown":
        return SecurityTier.S1
    level = int(classification_level)
    if level <= 1:
        return SecurityTier.S0
    if level == 2:
        return SecurityTier.S1
    return SecurityTier.S2


def compute_tier(card: KBCard) -> SecurityTier:
    """Derive the security tier for a KB Card (A.3)."""
    return security_tier_for(card.access.classificationLevel, card.access.ethicalWallSensitive)
