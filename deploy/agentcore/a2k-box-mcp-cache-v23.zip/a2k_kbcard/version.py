"""The A2K contract version this SDK family implements.

Kept as a single constant so it is trivial to bump across the whole workspace, and so
model defaults, envelope headers, and schema ``$id``s stay in agreement.
"""

from __future__ import annotations

A2K_VERSION = "0.1"
