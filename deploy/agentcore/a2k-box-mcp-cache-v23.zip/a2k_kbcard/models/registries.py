"""A2K 0.1 controlled vocabularies. Source: A2K-KBCard-Schema Appendix A.

One class per registry in ``a2k_kbcard/schema/_schemas/registries.schema.json`` (authoritative for
membership). Every enumerated value in the suite lives here as a ``StrEnum`` with the exact,
case-sensitive wire value; other models reference these and never restate a value. The two
scales (classification, authority) are unions (``int | Literal["unknown"]``); their asserted
variants are bounded integers.

Appendix A of A2K-KBCard-Schema is authoritative for vocabulary membership.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Literal

from annotated_types import Ge, Le


class ContractVersion(StrEnum):
    """A.1. The A2K contract version. Core fields change only with a MINOR bump."""

    V0_1 = "0.1"


class Operation(StrEnum):
    """A.2. Every A2K operation: four consumption, two discovery, one administration."""

    SEARCH = "search"
    ASK = "ask"
    EXPLAIN = "explain"
    GET_DOCUMENT = "getDocument"
    RESOLVE = "resolve"
    GET_CARD = "getCard"
    REGISTER = "register"


class ConsumptionOperation(StrEnum):
    """The consumption members of Operation; the only values a card may advertise."""

    SEARCH = "search"
    ASK = "ask"
    EXPLAIN = "explain"
    GET_DOCUMENT = "getDocument"


class DiscoveryOperation(StrEnum):
    """The discovery members of Operation, served by a Catalog role."""

    RESOLVE = "resolve"
    GET_CARD = "getCard"


class AdminOperation(StrEnum):
    """The administration member of Operation. Separately authorized."""

    REGISTER = "register"


class Transport(StrEnum):
    """A.2. Wire protocol of an EndpointBinding."""

    HTTPS_JSON = "https-json"
    MCP = "mcp"


class AuthMode(StrEnum):
    """A.2. The identity a KB requires. none only at classification level 0."""

    NONE = "none"
    DELEGATED = "delegated"
    SERVICE = "service"


class PrincipalType(StrEnum):
    """A.2. Prefix of ownerId and other principal references, in the form {type}:{id}."""

    USER = "user"
    GROUP = "group"
    SERVICE = "service"


class Feature(StrEnum):
    """A.2. Core features a caller may require through requirements.features."""

    STRICT_GROUNDING = "strict-grounding"


class Extension(StrEnum):
    """A.2. Registered extension names. The card key is urn:a2k:ext:{name}."""

    SIGNATURE = "signature"
    STREAMING = "streaming"
    A2A_BINDING = "a2a-binding"
    SOURCE_HASH = "source-hash"
    CONFLICT_REPORT = "conflict-report"
    GOVERNANCE_ATTESTATION = "governance-attestation"
    ETHICAL_WALL = "ethical-wall"
    KNOWLEDGE_TRACE = "knowledge-trace"
    REGULATED = "regulated"


class DeclaredLifecycleStatus(StrEnum):
    """A.3. The statuses an owner declares on a card (lifecycle.status)."""

    ACTIVE = "active"
    DRAFT = "draft"
    DEPRECATED = "deprecated"
    SUPERSEDED = "superseded"
    ARCHIVED = "archived"


class LifecycleStatus(StrEnum):
    """A.3. The KB's lifecycle state, declared by its owner or applied by the Catalog role."""

    ACTIVE = "active"
    DRAFT = "draft"
    DEPRECATED = "deprecated"
    SUPERSEDED = "superseded"
    ARCHIVED = "archived"
    SUSPENDED = "suspended"
    UNKNOWN = "unknown"


class SecurityTier(StrEnum):
    """A.3. Derived from the card, never declared."""

    S0 = "S0"
    S1 = "S1"
    S2 = "S2"


class Provenance(StrEnum):
    """A.3. Origin of the content. Independent of authority; never an approval."""

    FIRST_PARTY = "first-party"
    VENDOR = "vendor"
    DERIVED = "derived"
    PERSONAL = "personal"


class RegistrationStatus(StrEnum):
    """A.3. Status of a registration at the Catalog role."""

    REGISTERED = "registered"
    PENDING_APPROVAL = "pending-approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    QUARANTINED = "quarantined"


class IndexedRegistrationStatus(StrEnum):
    """The members of RegistrationStatus a register success may report."""

    REGISTERED = "registered"
    PENDING_APPROVAL = "pending-approval"
    APPROVED = "approved"


class StalenessAction(StrEnum):
    """A.3. What the KB does with evidence older than staleness.maxAgeSeconds."""

    WARN = "warn"
    EXCLUDE = "exclude"


class PiiHandling(StrEnum):
    """A.3. Whether personal data held in the KB may be returned to callers."""

    NOT_ALLOWED = "not-allowed"
    REDACTED = "redacted"
    ALLOWED = "allowed"


class Purpose(StrEnum):
    """A.4. One vocabulary for context.purpose, policies.allowedUse and disallowedUse."""

    ANSWERING = "answering"
    SUMMARIZATION = "summarization"
    SEARCH = "search"
    CITATION = "citation"
    EVALUATION = "evaluation"
    BULK_EXPORT = "bulk-export"
    MODEL_TRAINING = "model-training"
    EXTERNAL_DISCLOSURE = "external-disclosure"


class RiskLevel(StrEnum):
    """A.4. Caller-declared task risk. Advisory; may raise policy floors, never lowers them."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ResponseOutcome(StrEnum):
    """A.5. data.outcome of ask and explain."""

    ANSWERED = "answered"
    PARTIAL = "partial"
    REFUSED = "refused"
    OUT_OF_SCOPE = "out-of-scope"
    CLARIFICATION_REQUIRED = "clarification-required"
    HUMAN_REVIEW_REQUIRED = "human-review-required"


class RefusalCode(StrEnum):
    """A.5. Substantive non-answers inside a successful envelope."""

    OUT_OF_SCOPE = "OUT_OF_SCOPE"
    AMBIGUOUS_QUERY = "AMBIGUOUS_QUERY"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    EVIDENCE_TOO_OLD = "EVIDENCE_TOO_OLD"
    GROUNDING_VIOLATION = "GROUNDING_VIOLATION"
    HUMAN_REVIEW_REQUIRED = "HUMAN_REVIEW_REQUIRED"
    PURPOSE_NOT_ALLOWED = "PURPOSE_NOT_ALLOWED"
    POINT_IN_TIME_UNSUPPORTED = "POINT_IN_TIME_UNSUPPORTED"
    CONFLICT_UNRESOLVED = "CONFLICT_UNRESOLVED"


class ClaimStatus(StrEnum):
    """A.5. Evidence relations only; response-level conditions are outcomes."""

    SUPPORTED = "SUPPORTED"
    REFUTED = "REFUTED"
    DISPUTED = "DISPUTED"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"


class GroundingStatus(StrEnum):
    """A.5. How much of the answer is accounted for by claims with usable evidence."""

    STRICT_SATISFIED = "strict-satisfied"
    SUPPORTED = "supported"
    PARTIAL = "partial"
    UNSUPPORTED = "unsupported"


class GroundingMethod(StrEnum):
    """A.5. How the KB established the claim statuses."""

    EXTRACTIVE = "extractive"
    RETRIEVAL_ATTRIBUTION = "retrieval-attribution"
    NLI_ENTAILMENT = "nli-entailment"
    HEURISTIC = "heuristic"
    LLM_SELF_REPORT = "llm-self-report"
    UNKNOWN = "unknown"


class AccessDecisionValue(StrEnum):
    """A.5. accessDecision.decision on non-public successes. Denials are errors."""

    ALLOWED = "allowed"
    REDACTED = "redacted"
    PARTIAL = "partial"


class AuditStatus(StrEnum):
    """A.5. recorded requires recordRef."""

    RECORDED = "recorded"
    NOT_REQUIRED = "not-required"


class ProducerRole(StrEnum):
    """A.5. producedBy.role on KCP successes."""

    KB = "kb"
    GATEWAY = "gateway"


class Encoding(StrEnum):
    """A.5. getDocument content encoding. Required whenever content is present."""

    UTF_8 = "utf-8"
    BASE64 = "base64"


class SelectorType(StrEnum):
    """A.5. W3C Web Annotation selector types."""

    TEXT_QUOTE = "TextQuoteSelector"
    TEXT_POSITION = "TextPositionSelector"
    FRAGMENT = "FragmentSelector"


class ScopeMatch(StrEnum):
    """A.5. Discovery signal: whether the query falls inside the card's declared scope."""

    IN_SCOPE = "in-scope"
    PARTIAL = "partial"
    UNKNOWN = "unknown"


class ErrorCode(StrEnum):
    """A.6. Protocol failures, inside a failure envelope (ok: false)."""

    INVALID_REQUEST = "INVALID_REQUEST"
    SCHEMA_VALIDATION_FAILED = "SCHEMA_VALIDATION_FAILED"
    UNSUPPORTED_VERSION = "UNSUPPORTED_VERSION"
    UNSUPPORTED_OPERATION = "UNSUPPORTED_OPERATION"
    REQUIRED_FEATURE_UNSUPPORTED = "REQUIRED_FEATURE_UNSUPPORTED"
    AUTHENTICATION_REQUIRED = "AUTHENTICATION_REQUIRED"
    AUTHORIZATION_FAILED = "AUTHORIZATION_FAILED"
    ACCESS_DENIED = "ACCESS_DENIED"
    NOT_FOUND = "NOT_FOUND"
    PAGINATION_CURSOR_INVALID = "PAGINATION_CURSOR_INVALID"
    RATE_LIMITED = "RATE_LIMITED"
    TIMEOUT = "TIMEOUT"
    UPSTREAM_ERROR = "UPSTREAM_ERROR"
    AUDIT_UNAVAILABLE = "AUDIT_UNAVAILABLE"
    KB_SUSPENDED = "KB_SUSPENDED"
    INTERNAL_ERROR = "INTERNAL_ERROR"


class AdminErrorCode(StrEnum):
    """A.6. Returned only by the administration surface (register)."""

    REGISTRATION_REJECTED = "REGISTRATION_REJECTED"
    BINDING_REQUIRED = "BINDING_REQUIRED"
    ID_COLLISION = "ID_COLLISION"
    AUTHORITY_COLLISION = "AUTHORITY_COLLISION"


class GovernanceFlag(StrEnum):
    """A.3 / A2K-KRP §10. Conditions the Catalog role computes per card revision."""

    ORPHANED = "orphaned"
    SUPERSEDED = "superseded"
    DEPRECATED = "deprecated"
    AUTHORITY_COLLISION = "authority-collision"
    SCHEMA_INVALID = "schema-invalid"
    ACCESS_POLICY_DRIFT = "access-policy-drift"


class ValidationRuleId(StrEnum):
    """A2K-KBCard-Schema §13. The cross-field validation rules reported by register."""

    VAL_001 = "A2K-VAL-001"
    VAL_002 = "A2K-VAL-002"
    VAL_003 = "A2K-VAL-003"
    VAL_004 = "A2K-VAL-004"
    VAL_005 = "A2K-VAL-005"
    VAL_006 = "A2K-VAL-006"
    VAL_007 = "A2K-VAL-007"


# --- Numeric scales -----------------------------------------------------------------

#: A.3. Sensitivity on the enterprise scale, 0 (public) to 4 (highly restricted), or
#: ``"unknown"`` (treated as 2 for tier derivation). Higher is more sensitive.
ClassificationLevel = Annotated[int, Ge(0), Le(4)] | Literal["unknown"]

#: A.3. Effective authority: 0 canonical, 1 guidance, ``"unknown"`` when no current trusted
#: assertion exists. Lower is stronger.
AuthorityLevel = Annotated[int, Ge(0), Le(1)] | Literal["unknown"]

#: The integer members of ClassificationLevel (filter maxClassificationLevel).
AssertedClassificationLevel = Annotated[int, Ge(0), Le(4)]

#: The integer members of AuthorityLevel (Assertion.authorityLevel, filters, register).
AssertedAuthorityLevel = Annotated[int, Ge(0), Le(1)]
