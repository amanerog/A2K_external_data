"""KB Card model. Source: A2K-KBCard-Schema §4–§13 (``a2k_kbcard/schema/_schemas/kb-card.schema.json``).

Closed pydantic mirror of the KB Card: the governance metadata every KB publishes. A card
carries no endpoint (``EndpointBinding``) and no authority (``Assertion``). Unknown core
members are rejected (``extra="forbid"``, VAL-006); only ``extensions`` admits members a core
validator does not know. The JSON Schema (``a2k_kbcard.schema``) is the authoritative gate;
these validators mirror the schema-expressible VAL rules (VAL-002, VAL-003, VAL-005, VAL-006).
"""

from __future__ import annotations

from typing import Any

from pydantic import field_validator, model_validator

from a2k_kbcard.models.common import (
    A2KModel,
    Date,
    Duration,
    KbId,
    LanguageTag,
    NonEmptyString,
    PrincipalRef,
    Timestamp,
    UniqueStringArray,
    Uri,
)
from a2k_kbcard.models.registries import (
    AuthMode,
    ClassificationLevel,
    ConsumptionOperation,
    ContractVersion,
    DeclaredLifecycleStatus,
    Extension,
    PiiHandling,
    Provenance,
    Purpose,
    StalenessAction,
)

_EXTENSION_KEYS = frozenset(f"urn:a2k:ext:{ext.value}" for ext in Extension)


class Ownership(A2KModel):
    """§5. One accountable owner and one monitored contact."""

    ownerId: PrincipalRef
    contact: NonEmptyString


class Lifecycle(A2KModel):
    """§6. The KB's lifecycle state as declared by its owner (VAL-005)."""

    status: DeclaredLifecycleStatus
    cardUpdatedAt: Timestamp | None = None
    replacementKbId: KbId | None = None

    @model_validator(mode="after")
    def _superseded_needs_replacement(self) -> Lifecycle:
        if self.status == DeclaredLifecycleStatus.SUPERSEDED and self.replacementKbId is None:
            raise ValueError("A2K-VAL-005: lifecycle.status 'superseded' requires replacementKbId")
        return self


class Access(A2KModel):
    """§7. Declarative metadata for discovery filtering and tier derivation (VAL-001)."""

    classificationLevel: ClassificationLevel
    ethicalWallSensitive: bool = False


class Auth(A2KModel):
    """§8. The identity the KB requires and the scopes a credential MUST carry."""

    mode: AuthMode
    scopes: UniqueStringArray | None = None


class PointInTime(A2KModel):
    """§9.2. Whether the KB can evaluate a query as of a past date."""

    supported: bool
    earliest: Date | None = None


class KnowledgeProfile(A2KModel):
    """§9. What the KB covers."""

    domains: list[NonEmptyString]
    scope: NonEmptyString
    topics: UniqueStringArray | None = None
    languages: list[LanguageTag] | None = None
    vocabularyRef: Uri | None = None
    pointInTime: PointInTime | None = None

    @field_validator("domains")
    @classmethod
    def _domains_non_empty(cls, value: list[str]) -> list[str]:
        if not value:
            raise ValueError("knowledgeProfile.domains must be non-empty")
        return value


class Policies(A2KModel):
    """§4.1. Purpose limits, query retention and personal-data handling."""

    allowedUse: list[Purpose] | None = None
    disallowedUse: list[Purpose] | None = None
    queryRetention: Duration | None = None
    piiHandling: PiiHandling | None = None


class Staleness(A2KModel):
    """§4.2. The KB's own default for evidence age."""

    maxAgeSeconds: int
    action: StalenessAction

    @field_validator("maxAgeSeconds")
    @classmethod
    def _non_negative(cls, value: int) -> int:
        if value < 0:
            raise ValueError("staleness.maxAgeSeconds must be >= 0")
        return value


class KBCard(A2KModel):
    """A2K-KBCard-Schema §4. One Knowledge Base's published card."""

    a2kVersion: ContractVersion
    id: KbId
    kbCardVersion: NonEmptyString
    name: NonEmptyString
    description: NonEmptyString
    ownership: Ownership
    lifecycle: Lifecycle
    access: Access
    auth: Auth
    knowledgeProfile: KnowledgeProfile
    operations: list[ConsumptionOperation]
    provenance: Provenance | None = None
    policies: Policies | None = None
    staleness: Staleness | None = None
    explainRetention: Duration | None = None
    extensions: dict[str, dict[str, Any]] | None = None

    @field_validator("operations")
    @classmethod
    def _operations_unique(cls, value: list[ConsumptionOperation]) -> list[ConsumptionOperation]:
        if len(set(value)) != len(value):
            raise ValueError("A2K-VAL-003: operations MUST be unique")
        return value

    @field_validator("extensions")
    @classmethod
    def _extension_keys_in_registry(cls, value: dict[str, Any] | None) -> dict[str, Any] | None:
        if value is None:
            return value
        unknown = set(value) - _EXTENSION_KEYS
        if unknown:
            raise ValueError(f"A2K-VAL-006: unknown extension keys {sorted(unknown)}")
        return value

    @model_validator(mode="after")
    def _val_rules(self) -> KBCard:
        ops = set(self.operations)

        # A2K-VAL-002: auth.mode none only at classification level 0, and no scopes.
        if self.auth.mode == AuthMode.NONE:
            if self.access.classificationLevel != 0:
                raise ValueError("A2K-VAL-002: auth.mode 'none' requires access.classificationLevel 0")
            if self.auth.scopes is not None:
                raise ValueError("A2K-VAL-002: auth.mode 'none' presents no credential, so scopes is absent")

        # A2K-VAL-003: operation dependencies and explainRetention.
        if ConsumptionOperation.ASK in ops and ConsumptionOperation.SEARCH not in ops:
            raise ValueError("A2K-VAL-003: 'ask' requires 'search'")
        if ConsumptionOperation.EXPLAIN in ops and ConsumptionOperation.ASK not in ops:
            raise ValueError("A2K-VAL-003: 'explain' requires 'ask'")
        if ConsumptionOperation.EXPLAIN in ops and self.explainRetention is None:
            raise ValueError("A2K-VAL-003: 'explain' requires explainRetention")
        return self


class KbCardStub(A2KModel):
    """§11 rule 2. What a card endpoint MAY serve anonymously at classification level 1+."""

    a2kVersion: ContractVersion
    auth: Auth
