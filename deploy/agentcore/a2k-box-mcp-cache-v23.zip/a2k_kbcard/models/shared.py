"""Shared Appendix A.7 objects owned by the KB Card document, reused by KRP and KCP.

Sources: ``endpoint-binding``, ``assertion``, ``kb-summary``, ``page-info``, ``refusal``,
``error`` and ``registration-validation`` schemas. Closed models (``extra="forbid"``) except
``Error.details``, which is an open object (the members below are the ones the spec names).
The JSON Schema remains the authoritative structural gate.
"""

from __future__ import annotations

from typing import Any

from pydantic import model_serializer, model_validator
from pydantic_core.core_schema import SerializerFunctionWrapHandler

from a2k_kbcard.models.common import (
    A2KModel,
    A2KOpenModel,
    HttpsUrl,
    KbId,
    NonEmptyString,
    ResourceIndicator,
    Timestamp,
)
from a2k_kbcard.models.registries import (
    AdminErrorCode,
    AssertedAuthorityLevel,
    ClassificationLevel,
    ConsumptionOperation,
    ContractVersion,
    ErrorCode,
    Provenance,
    RefusalCode,
    SecurityTier,
    Transport,
    ValidationRuleId,
)


class EndpointBinding(A2KModel):
    """A.7. Where a KB is reachable. A KB Card never carries an endpoint."""

    url: HttpsUrl
    transport: Transport
    resource: ResourceIndicator | None = None
    supportedVersions: list[ContractVersion] | None = None


class Assertion(A2KModel):
    """A.7. The Catalog role's statement of a KB's effective authority at one card revision."""

    issuer: KbId
    kbId: KbId
    kbCardVersion: NonEmptyString
    authorityLevel: AssertedAuthorityLevel
    scope: NonEmptyString
    securityTier: SecurityTier
    assertedAt: Timestamp
    validUntil: Timestamp
    policyVersion: NonEmptyString | None = None


class KbSummary(A2KModel):
    """A.7. The abbreviated discovery result returned by resolve."""

    id: KbId
    kbCardVersion: NonEmptyString
    name: NonEmptyString
    operations: list[ConsumptionOperation]
    classificationLevel: ClassificationLevel
    securityTier: SecurityTier
    provenance: Provenance | None = None


class PageInfo(A2KModel):
    """A.7. nextCursor is the only member and the only legal null in the suite."""

    nextCursor: str | None

    @model_serializer(mode="wrap")
    def _always_emit_cursor(self, handler: SerializerFunctionWrapHandler) -> dict[str, Any]:
        # nextCursor is REQUIRED and is the sole legal null; keep it even under exclude_none.
        data = handler(self)
        data["nextCursor"] = self.nextCursor
        return data


class Refusal(A2KModel):
    """A.7. A substantive non-answer inside a successful envelope."""

    code: RefusalCode
    reason: NonEmptyString
    retryable: bool


class Error(A2KModel):
    """A.7. The error member of a failure envelope. ``details`` is an open object."""

    code: ErrorCode | AdminErrorCode
    message: NonEmptyString
    retryable: bool
    details: ErrorDetails | dict[str, Any] | None = None


class ErrorDetails(A2KOpenModel):
    """Open object; the members named by the spec are typed for convenience."""

    supportedVersions: list[str] | None = None
    unsupportedFeatures: list[str] | None = None
    validation: RegistrationValidation | None = None


class RuleResult(A2KModel):
    """One entry of a registration validation result (message iff a rule failed)."""

    id: ValidationRuleId
    passed: bool
    message: NonEmptyString | None = None

    @model_validator(mode="after")
    def _message_iff_failed(self) -> RuleResult:
        if self.passed and self.message is not None:
            raise ValueError("registration rule message is present only for a failed rule")
        if not self.passed and self.message is None:
            raise ValueError("a failed registration rule carries a message")
        return self


class RegistrationValidation(A2KModel):
    """A2K-KRP §12.2. Schema validity plus the §13 rule results (no rule appears twice)."""

    schemaValid: bool
    rules: list[RuleResult]

    @model_validator(mode="after")
    def _rules_unique(self) -> RegistrationValidation:
        ids = [r.id for r in self.rules]
        if len(set(ids)) != len(ids):
            raise ValueError("registration validation rules must not repeat a rule id")
        return self


Error.model_rebuild()
ErrorDetails.model_rebuild()
