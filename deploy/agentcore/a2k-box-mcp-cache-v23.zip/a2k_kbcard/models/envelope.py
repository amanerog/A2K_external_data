"""Shared response-envelope primitives. Source: ``a2k_kbcard/schema/_schemas/envelope.schema.json`` (§2).

The disjoint success/failure envelopes are shared by both the resolution (A2K-KRP) and
consumption (A2K-KCP) protocols. The truly common pieces live here in the foundation so
neither protocol SDK depends on the other:

- ``Failure`` — one shape for every operation (``ok: false``);
- ``SuccessBase`` — the members common to every success (``ok: true``); each per-operation
  success model adds ``operation`` (a ``Literal`` const) and its typed ``data``.

The KCP-only success members (kbId, gateway fan-out, accessDecision, audit) live in
``a2k_kcp.models.envelope``. The JSON Schema is the authoritative structural gate.
"""

from __future__ import annotations

from typing import Literal

from a2k_kbcard.models.common import A2KModel, RequestId, ResponseId, Timestamp
from a2k_kbcard.models.registries import ContractVersion, Operation
from a2k_kbcard.models.shared import Error


class SuccessBase(A2KModel):
    """§2.2. The members common to every success envelope (``ok: true``)."""

    a2kVersion: ContractVersion
    ok: Literal[True] = True
    requestId: RequestId
    responseId: ResponseId
    generatedAt: Timestamp
    # `operation` (a Literal const) and `data` (typed) are added by each subclass.


class Failure(A2KModel):
    """§2.3, §2.5. A protocol failure for any operation. Nothing names the target.

    ``operation`` and ``requestId`` are echoed when the request supplied a valid value and
    omitted otherwise — the only cases in which they may be absent.
    """

    a2kVersion: ContractVersion
    ok: Literal[False] = False
    operation: Operation | None = None
    requestId: RequestId | None = None
    responseId: ResponseId
    generatedAt: Timestamp
    error: Error
