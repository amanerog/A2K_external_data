"""Delegated identity. Source: A2K request base ``$defs/OnBehalfOf`` (A2K-KCP §3.1).

In 0.1 the on-behalf-of member is minimal: the human subject the client believes it is acting
for. It is a hint only — it MUST equal the verified subject and never widens access. Both KRP
and KCP reuse this closed model.
"""

from __future__ import annotations

from a2k_kbcard.models.common import A2KModel, UserRef


class OnBehalfOf(A2KModel):
    """§3.1. The subject the client believes it is acting for, a ``user:`` principal."""

    subject: UserRef
