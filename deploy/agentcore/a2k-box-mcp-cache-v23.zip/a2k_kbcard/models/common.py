"""A2K 0.1 common primitives. Source: ``a2k_kbcard/schema/_schemas/common.schema.json``.

Constrained scalar and container types shared by every A2K 0.1 model, plus the two shared
pydantic base classes. Every constrained string carries the exact ``pattern`` from
``common.schema.json`` (Draft 2020-12 does not assert ``format`` by default, so the pattern is
the shape check). Some patterns use look-around (e.g. ``Duration``), so the base models set
``regex_engine="python-re"``; the JSON Schema remains the authoritative structural gate.
"""

from __future__ import annotations

from typing import Annotated

from annotated_types import Ge, Le, MinLen
from pydantic import BaseModel, ConfigDict, StringConstraints

# --- Shared base models -------------------------------------------------------------

#: Closed base: unknown members are rejected (VAL-006 native), matching the schemas'
#: ``additionalProperties: false``. ``python-re`` is required for look-around patterns.
_MODEL_CONFIG = ConfigDict(extra="forbid", use_enum_values=True, regex_engine="python-re")


class A2KModel(BaseModel):
    """Closed A2K model: extra members forbidden, enums serialized by value."""

    model_config = _MODEL_CONFIG


class A2KOpenModel(BaseModel):
    """Open A2K base for the two documentation base objects and ``error.details``."""

    model_config = ConfigDict(extra="allow", use_enum_values=True, regex_engine="python-re")


# --- Constrained string aliases (patterns copied from common.schema.json) ------------

#: A2K-KBCard-Schema §3. urn:a2k:{org}:{segment}(:{segment})+.
KbId = Annotated[str, StringConstraints(pattern=r"^urn:a2k:[a-z0-9-]+:[a-z0-9-]+(:[a-z0-9-]+)+$")]

#: A2K-KBCard-Schema §5. {type}:{id} where {type} is a PrincipalType.
PrincipalRef = Annotated[str, StringConstraints(pattern=r"^(user|group|service):.+$")]

#: A2K-KCP §3.1. A PrincipalRef whose type is user.
UserRef = Annotated[str, StringConstraints(pattern=r"^user:.+$")]

#: A2K-KRP §12.1. A PrincipalRef whose type is service.
ServiceRef = Annotated[str, StringConstraints(pattern=r"^service:.+$")]

#: RFC 3339 UTC timestamp with a Z suffix; optional fractional second.
Timestamp = Annotated[
    str,
    StringConstraints(
        pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])T([01]\d|2[0-3]):[0-5]\d:[0-5]\d(\.\d+)?Z$"
    ),
]

#: A date without a time, YYYY-MM-DD.
Date = Annotated[str, StringConstraints(pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$")]

#: ISO 8601 duration such as P7D or PT300S.
Duration = Annotated[
    str,
    StringConstraints(pattern=r"^P(?!$)(\d+W|(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+(\.\d+)?S)?)?)$"),
]

#: Client-issued identifier, 1 to 128 characters.
RequestId = Annotated[str, StringConstraints(min_length=1, max_length=128)]

#: Responder-issued identifier, unique within the responder.
ResponseId = Annotated[str, StringConstraints(min_length=1)]

#: An absolute URI with a scheme.
Uri = Annotated[str, StringConstraints(pattern=r"^[A-Za-z][A-Za-z0-9+.-]*:[^\s]+$")]

#: An absolute https URL with a host.
HttpsUrl = Annotated[str, StringConstraints(pattern=r"^https://[^\s/?#]+[^\s]*$")]

#: An absolute URI without a fragment (RFC 8707 resource indicator).
ResourceIndicator = Annotated[str, StringConstraints(pattern=r"^[A-Za-z][A-Za-z0-9+.-]*:[^\s#]+$")]

#: A BCP 47 language tag. Permissive shape check only.
LanguageTag = Annotated[str, StringConstraints(min_length=2, pattern=r"^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8})*$")]

#: A number in [0, 1]. Used by passage.score and signals.topicMatch.
UnitInterval = Annotated[float, Ge(0), Le(1)]

#: A non-empty string.
NonEmptyString = Annotated[str, StringConstraints(min_length=1)]

#: An array of unique non-empty strings; non-empty when present. Uniqueness is asserted by
#: the JSON Schema (``uniqueItems``); the pydantic mirror enforces only non-emptiness.
UniqueStringArray = Annotated[list[NonEmptyString], MinLen(1)]
