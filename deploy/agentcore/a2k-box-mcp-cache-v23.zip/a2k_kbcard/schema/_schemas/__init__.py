"""Vendored A2K JSON Schemas (package data). Not importable API — loaded via importlib.resources."""
