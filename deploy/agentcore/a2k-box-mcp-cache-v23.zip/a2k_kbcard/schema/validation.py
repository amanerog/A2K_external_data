"""Schema loading + validation, decoupled from any particular file layout.

The single canonical schema package is vendored inside this package at ``_schemas/`` and read
here via ``importlib.resources`` so validation works identically from a source checkout or an
installed wheel — no repo-relative paths.

Because all 35 schemas resolve inside this one package and every ``$ref`` is an intra-suite
URN, ``build_registry()`` alone resolves everything offline. The resolution (A2K-KRP) and
consumption (A2K-KCP) SDKs reuse this registry rather than vendoring their own copies.
"""

from __future__ import annotations

import functools
import json
from collections.abc import Iterable
from importlib.resources import files
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import ValidationError, best_match
from referencing import Registry, Resource

_PACKAGE = "a2k_kbcard.schema._schemas"

#: Every A2K 0.1 schema ``$id`` has the shape ``urn:a2k:schemas:{name}:0.1``.
_ID_PREFIX = "urn:a2k:schemas:"
_ID_SUFFIX = ":0.1"


class SchemaValidationError(Exception):
    """Raised when an instance fails its JSON Schema.

    Carries the first errors as structured data so a transport binding can surface a
    ``SCHEMA_VALIDATION_FAILED`` response without leaking internals.
    """

    def __init__(self, message: str, *, errors: list[dict[str, Any]] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.errors = errors or []


def schema_id(name: str) -> str:
    """The ``$id`` URN for a schema, e.g. ``schema_id("kb-card")``.

    A name may carry a JSON-pointer fragment (``"envelope#/$defs/Failure"``); the version is
    inserted before the fragment, yielding ``urn:a2k:schemas:envelope:0.1#/$defs/Failure``.
    """
    base, sep, fragment = name.partition("#")
    return f"{_ID_PREFIX}{base}{_ID_SUFFIX}{sep}{fragment}"


def load_schema(filename: str) -> dict[str, Any]:
    """Load a bundled schema by file name (e.g. ``"kb-card.schema.json"``)."""
    text = files(_PACKAGE).joinpath(filename).read_text(encoding="utf-8")
    return json.loads(text)


def load_bundle(operation: str) -> dict[str, Any]:
    """Load a self-contained per-operation response bundle (A2K-KCP §10.2 MCP outputSchema).

    ``operation`` is a response operation name, e.g. ``"search"`` -> ``search-response.json``.
    Every ``$ref`` in a bundle is local, so it needs no registry. The self-contained bundles are
    vendored alongside the schemas (``*-response.json`` next to the ``*.schema.json`` files).
    """
    name = operation if operation.endswith("-response") else f"{operation}-response"
    text = files(_PACKAGE).joinpath(f"{name}.json").read_text(encoding="utf-8")
    return json.loads(text)


def iter_schema_resources() -> Iterable[tuple[str, Resource]]:
    """Yield ``($id, Resource)`` for every canonical schema this package vendors.

    Only ``*.schema.json`` files are part of the resolution registry; the self-contained
    ``*-response.json`` bundles carry no ``$id`` and are excluded.
    """
    for entry in files(_PACKAGE).iterdir():
        name = entry.name
        if not name.endswith(".schema.json"):
            continue
        data = json.loads(entry.read_text(encoding="utf-8"))
        if "$id" in data:
            yield data["$id"], Resource.from_contents(data)


@functools.cache
def _resources() -> tuple[tuple[str, Resource], ...]:
    return tuple(iter_schema_resources())


def build_registry(*extra: tuple[str, Resource]) -> Registry:
    """A referencing ``Registry`` of the foundation schemas plus any ``extra`` resources."""
    return Registry().with_resources([*_resources(), *extra])


@functools.cache
def _validator_for(schema_id_: str) -> Draft202012Validator:
    # Validate through a ``$ref`` wrapper so an optional JSON-pointer fragment
    # (e.g. ``#/$defs/Failure``) resolves inside the registry while the target's own base
    # scope is preserved for its nested relative ``$ref``s.
    return Draft202012Validator({"$ref": schema_id_}, registry=build_registry())


def _instance_path(error: ValidationError) -> str:
    parts = list(error.absolute_path)
    return "/" + "/".join(str(p) for p in parts) if parts else ""


def _error_dict(error: ValidationError) -> dict[str, Any]:
    return {
        "path": list(error.absolute_path),
        "instancePath": _instance_path(error),
        "keyword": error.validator,
        "message": error.message,
    }


def validate(instance: Any, *, schema_id: str) -> None:  # noqa: A002 - stable public kwarg name
    """Validate ``instance`` against the schema with ``$id`` ``schema_id``.

    Raises :class:`SchemaValidationError` on failure. The first reported error is the
    most-specific one (``best_match`` descends into ``oneOf``/``anyOf``/``allOf`` context), so
    ``errors[0]["instancePath"]`` names the exact failing location.
    """
    validator = _validator_for(schema_id)
    errors = list(validator.iter_errors(instance))
    if not errors:
        return
    best = best_match(errors)
    ordered = [best, *(e for e in errors if e is not best)]
    raise SchemaValidationError(
        f"{schema_id} validation failed",
        errors=[_error_dict(e) for e in ordered[:25]],
    )


def validate_by_name(instance: Any, name: str) -> None:
    """Validate against the schema named ``name`` (e.g. ``"kb-card"``, ``"resolve-request"``)."""
    validate(instance, schema_id=schema_id(name))


def validate_card(instance: dict[str, Any]) -> None:
    """Validate a KB Card document against ``kb-card.schema.json``."""
    validate_by_name(instance, "kb-card")


def validate_kb_card_stub(instance: dict[str, Any]) -> None:
    """Validate a KB Card stub (A2K-KBCard-Schema §11 rule 2)."""
    validate_by_name(instance, "kb-card-stub")


def validate_a2k_message(instance: Any) -> None:
    """Validate any top-level A2K 0.1 wire shape via the ``a2k`` umbrella (tooling aid)."""
    validate_by_name(instance, "a2k")
