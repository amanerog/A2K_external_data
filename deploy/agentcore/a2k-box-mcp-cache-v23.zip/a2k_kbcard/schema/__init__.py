"""JSON Schema validation for A2K 0.1 artifacts (the schemas are the source of truth).

The foundation package vendors the single canonical schema suite (35 Draft 2020-12 schemas
plus the generated per-operation bundles) and exposes them as *composable registry resources*
so the resolution (A2K-KRP) and consumption (A2K-KCP) SDKs can build one registry spanning
the whole suite — every cross-object ``$ref`` is an intra-suite URN — without any network
access.
"""

from a2k_kbcard.schema.validation import (
    SchemaValidationError,
    build_registry,
    iter_schema_resources,
    load_bundle,
    load_schema,
    schema_id,
    validate,
    validate_a2k_message,
    validate_by_name,
    validate_card,
    validate_kb_card_stub,
)

__all__ = [
    "SchemaValidationError",
    "build_registry",
    "iter_schema_resources",
    "load_bundle",
    "load_schema",
    "schema_id",
    "validate",
    "validate_a2k_message",
    "validate_by_name",
    "validate_card",
    "validate_kb_card_stub",
]
