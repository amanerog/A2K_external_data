"""
Middleware for MCP authorization.
"""
